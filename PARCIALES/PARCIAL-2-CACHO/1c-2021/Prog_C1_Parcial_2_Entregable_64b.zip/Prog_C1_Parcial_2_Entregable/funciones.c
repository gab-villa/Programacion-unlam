/**//*             en los siguientes macroreemplazos indique:             *//**/
/**//*    su(s)         APELLIDO(S)     completo(s)                       *//**/
/**//*    su(s)         Nombre(S)       completo(s)                       *//**/
/**//*    su legajo     N�MERO DE DNI   con los puntos de mill�n y de mil *//**/
/**//*    COMISI�N                                                        *//**/
/**//*              reemplazando los que est�n como ejemplo               *//**/
#define APELLIDO    "P�REZ DEL R�O"
#define NOMBRE      "Juan Manuel"
#define DOCUMENTO   "22.333.444"
#define COMISION    "07(7299)"
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/** aqu� insertaremos nuestras observaciones y / o correcciones              **/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
#undef APELLIDO
#undef NOMBRE
#undef DOCUMENTO
#undef COMISION
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* CUALQUIER INCLUDE DE BIBLIOTECA QUE NECESITE, H�GALO DESDE AC� *//**/



/**//**//* CUALQUIER INCLUDE DE BIBLIOTECA QUE NECESITE, H�GALO HASTA AC� *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
#include "funciones.h"


/** Para el PUNTO 1 **/
int indexarArchivoCuentas_MIO(char *nombreArchivoCuentas, tArbol *p)
{
    return 0;
}
/** FIN de PUNTO 1 **/


/** Para el PUNTO 2 **/
int cargarArchivoNovedadesEnLista_MIO(FILE *fpPantalla,
                                  char *nombreArchivoNovedades,
                                  tLista *p)
{
    return 0;
}
/** FIN de PUNTO 2 **/


/** Para el PUNTO 3 **/
int cargarNovedadesEnColaDesdeLista_MIO(tLista *pl,
                                        tCola *pc,
                                        FILE *fpPantalla)
{
    return 0;
}
/** FIN de PUNTO 3 **/

/** Para el PUNTO 4 **/
int actualizarArchivoDeCuentasDesdeColaDeNovedades_MIO(FILE *fpPantalla,
                                                   char *nombreArchivoCuentas,
                                                   tCola *cola,
                                                   tArbol *indice)
{
    return 0;
}
/** FIN de PUNTO 4 **/

/** Para el PUNTO 5 **/
int podarIndiceYEncolarPodados_MIO(FILE *fpPantalla,
                               tArbol *indice,
                               tCola *cola,
                               int alturaPoda)
{
    return 0;
}
/** FIN de PUNTO 5 **/

/** Para el PUNTO 6 **/
int actualizarEstadosArchivoCuentasDesdeCola_MIO(FILE *fpPantalla,
                                                 char *nombreArchivoCuentas,
                                                 tCola *cola)
{
    return 0;
}
/** FIN de PUNTO 6 **/


/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

