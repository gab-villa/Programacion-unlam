/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* AC� NO DEBE HACER NINGUNA MODIFICACI�N                         *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>

#include "funciones.h"
#include "que_hice.h"

#include <stdlib.h>
#include <string.h>

void punto_1(FILE *fpPantalla, tArbol *indice);
void punto_2(FILE *fpPantalla, tLista *lista);
void punto_3(FILE *fpPantalla, tLista *lista, tCola *cola);
void punto_4(FILE *fpPantalla, tCola *cola, tArbol *indice);
void punto_5(FILE *fpPantalla, tArbol *indice, tCola *cola);
void punto_6(FILE *fpPantalla, tCola *cola);
#endif

