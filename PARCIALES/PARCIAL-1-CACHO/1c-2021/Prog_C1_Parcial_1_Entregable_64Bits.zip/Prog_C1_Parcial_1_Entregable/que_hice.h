#ifndef QUE_HICE_H_
#define QUE_HICE_H_

///#define CODIGO_ALUMNO

#ifdef CODIGO_ALUMNO
///    #define PUNTO_1
///    #define PUNTO_2
///    #define PUNTO_3
///    #define PUNTO_4
///    #define PUNTO_5
#endif // CODIGO_ALUMNO

#endif // QUE_HICE_H_
