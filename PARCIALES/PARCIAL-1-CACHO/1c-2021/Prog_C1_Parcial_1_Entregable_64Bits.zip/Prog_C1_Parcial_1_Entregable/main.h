/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//* AC� NO DEBE HACER NINGUNA MODIFICACI�N                         *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>

#include "funciones.h"
#include "que_hice.h"

#include <stdlib.h>
#include <string.h>

void punto_1(FILE *fpPantalla);
void punto_2(FILE *fpPantalla);
void punto_3(FILE *fpPantalla, tLista *pl);
void punto_4(FILE *fpPantalla, tLista *pl);
void punto_5(FILE *fpPantalla);
#endif

